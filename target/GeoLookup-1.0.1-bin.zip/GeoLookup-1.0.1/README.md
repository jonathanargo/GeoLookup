# GeoLookup
Converts an address into decimal degrees through Google's GeoCoding API.
